<?php
namespace Code\Entity;

use Code\DB\Entity;

class Products extends Entity{
    
}