<?php

require 'vendor/autoload.php';

define('VIEWS_PATH', 'views/');
define('HOME', 'http://192.168.2.124/index.php');